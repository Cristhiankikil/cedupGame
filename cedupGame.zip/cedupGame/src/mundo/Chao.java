package mundo;

import java.awt.image.BufferedImage;

public class Chao extends Tile{

	public Chao(int x, int y, BufferedImage sprite) {
		super(x, y, sprite);
		// TODO Auto-generated constructor stub
	}

}
