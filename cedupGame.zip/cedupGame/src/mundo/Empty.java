package mundo;

import java.awt.image.BufferedImage;

public class Empty extends Tile {

	public Empty(int x, int y, BufferedImage sprite) {
		super(x, y, sprite);
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
