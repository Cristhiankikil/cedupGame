/**
 * 
 */
/**
 * 
 */
module cedupGame {
	requires java.desktop;
	requires java.sql;
}