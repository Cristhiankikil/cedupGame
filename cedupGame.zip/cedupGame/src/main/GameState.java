package main;

public enum GameState {

	Game,
	Menu,
	GameOver,
	Opcoes,
	GameMenu,
	intrucoes,
	perguntinha
	
}
