package dataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class JogadasBd extends QuestionarioBd{
	public ArrayList<Jogador> BuscaAluno() throws ClassNotFoundException, SQLException {
        ArrayList<Jogador> list = new ArrayList<>();
        Conexao conex = new Conexao();
        String sql = "SELECT * FROM jogadas";
        Class.forName(conex.getDriver());
        Connection MyConn = DriverManager.getConnection(conex.getUrl(), conex.getUser(), conex.getSenha());
        Statement MyStm = MyConn.createStatement();
        ResultSet m = MyStm.executeQuery(sql);
        
        try {
            while (m.next()) {
            	Jogador cp = new Jogador();
                cp.setId(m.getInt("id"));
                cp.setNome(m.getString("nome_jogador"));
                
      
                list.add(cp);
            }
            m.close();
            MyStm.close();
            MyConn.close();
         
        } catch (Exception e) {
        	this.setErro(""+e);
            e.printStackTrace(); 
        }
        return list;
    }
	
}
