package dataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class Perguntas {
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPergunta() {
		return pergunta;
	}

	public void setPergunta(String pergunta) {
		this.pergunta = pergunta;
	}

	public String getResposta() {
		String cor = "#C0C0C0";
		if (!resposta.equals(resposta_esperada)) {
			cor = "red";
		} if (resposta.equals(resposta_esperada)) {
			cor = "green";
		} 
		
		if("null".equals(resposta)) {
			resposta = "<strong style='color:#C0C0C0;'>Não respondido</strong>";
		}
		if("f".equals(resposta)) {
			resposta = "<strong style='color:"+cor+";'>Falso!</strong>";
		}
		if("t".equals(resposta)) {
			resposta = "<strong style='color:"+cor+";'>Verdadeiro!</strong>";
		}
		return resposta;
	}

	public void setResposta(String resposta) {
		this.resposta = resposta;
	}

	public int getCod_questionario() {
		return cod_questionario;
	}

	public void setCod_questionario(int cod_questionario) {
		this.cod_questionario = cod_questionario;
	}
	public int getCod_pergunta() {
		return cod_pergunta;
	}

	public void setCod_pergunta(int cod_pergunta) {
		this.cod_pergunta = cod_pergunta;
	}
	
	
	int id = 0;
	int cod_pergunta = 0;
	
	int cod_jogada=0;
	public int getCod_jogada() {
		return cod_jogada;
	}

	public void setCod_jogada(int cod_jogada) {
		this.cod_jogada = cod_jogada;
	}


	String pergunta = "";
	String resposta = "n";
	String resposta_esperada = "";
	Boolean respondido;
	public Boolean getRespondido() {
		return respondido;
	}

	public void setRespondido(Boolean respondido) {
		this.respondido = respondido;
	}

	public String getResposta_esperada() {
		if("f".equals(resposta_esperada)) {
			resposta_esperada = "Falso!";
		}
		if("t".equals(resposta_esperada)) {
			resposta_esperada = "Verdadeiro!";
		}
		return resposta_esperada;
	}

	public void setResposta_esperada(String resposta_esperada) {
		this.resposta_esperada = resposta_esperada;
	}


	int cod_questionario = 0;
	
	public String toString() {
		return this.getPergunta();
	}
	
	

}
